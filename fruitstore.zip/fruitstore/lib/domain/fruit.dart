class Fruit{
  String name;
  String price;

  Fruit(this.name, this.price);
}