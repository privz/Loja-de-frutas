import 'package:fruitstore/domain/fruit.dart';

final fruitMock = [
  Fruit("Tangerina", "R\$4,00"),
  Fruit("Pera", "R\$10,00"),
  Fruit("Melancia", "R\$15,00"),
  Fruit("Pitaya", "R\$25,00"),
  Fruit("Banana", "R\$24,00")
];